package com.pagepilot

import android.app.Application

/** 程序一启动就挂上“崩溃记录”：万一闪退，把原因存下来，下次打开设置页能看到。 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            CrashLog.record(this, "程序崩溃（线程 " + thread.name + "）", error)
            old?.uncaughtException(thread, error)
        }
    }
}
