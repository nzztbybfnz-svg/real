package com.pagepilot

import android.content.Context
import android.os.Build
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 把出错信息存下来，下次打开设置页时显示出来，方便截图排查。 */
object CrashLog {
    private const val FILE = "pagepilot_crash"
    private const val KEY = "last"

    fun record(c: Context, where: String, t: Throwable) {
        try {
            val sw = StringWriter()
            t.printStackTrace(PrintWriter(sw))
            val stack = sw.toString().lines().take(18).joinToString("\n")
            val time = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())
            val text = "[" + time + "] " + where + "\n" +
                "手机：" + Build.BRAND + " " + Build.MODEL +
                "，Android " + Build.VERSION.RELEASE + "（API " + Build.VERSION.SDK_INT + "）\n" +
                stack
            // 用 commit() 同步写入：程序马上就要退出时，异步写入会丢
            c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, text).commit()
        } catch (e: Throwable) {
            // 记录失败就算了，不能再引起新的错误
        }
    }

    fun last(c: Context): String? = try {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, null)
    } catch (e: Throwable) {
        null
    }

    fun clear(c: Context) {
        try {
            c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().remove(KEY).commit()
        } catch (e: Throwable) {
            // 忽略
        }
    }
}
