package com.pagepilot

import android.content.Context
import android.content.SharedPreferences

/** 用户设置，存在 SharedPreferences 里。 */
object Prefs {
    // 翻页方式
    const val MODE_VERTICAL = 0   // 上下滑动：上滑 = 下一页
    const val MODE_HORIZONTAL = 1 // 左右滑动：左滑 = 下一页
    const val MODE_TAP = 2        // 点击屏幕右侧 = 下一页，左侧 = 上一页
    const val MODE_SCROLL = 3     // 系统滚动指令（无障碍滚动动作），手势没反应时的备用方式

    // 滑动力度（只对前两种滑动方式有效）
    const val STYLE_NORMAL = 0    // 标准：220 毫秒，滑过约 40% 屏幕
    const val STYLE_FAST = 1      // 快速甩动：100 毫秒，滑过约 55% 屏幕
    const val STYLE_SLOW = 2      // 慢速拖动：450 毫秒，滑过约 50% 屏幕

    // 自动翻页到最后一页之后
    const val LOOP_PINGPONG = 0   // 往返：倒着翻回第一页，再正着翻
    const val LOOP_RESTART = 1    // 快速退回第一页，再继续往后翻
    const val LOOP_TOP = 2        // 自动检测到底，回到最顶部再继续往后翻（不用填总页数）

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("pagepilot", Context.MODE_PRIVATE)

    fun gestureMode(c: Context): Int = sp(c).getInt("gestureMode", MODE_VERTICAL).coerceIn(0, 3)
    fun setGestureMode(c: Context, v: Int) = sp(c).edit().putInt("gestureMode", v).apply()

    fun swipeStyle(c: Context): Int = sp(c).getInt("swipeStyle", STYLE_NORMAL).coerceIn(0, 2)
    fun setSwipeStyle(c: Context, v: Int) = sp(c).edit().putInt("swipeStyle", v).apply()

    fun invert(c: Context): Boolean = sp(c).getBoolean("invert", false)
    fun setInvert(c: Context, v: Boolean) = sp(c).edit().putBoolean("invert", v).apply()

    fun feedback(c: Context): Boolean = sp(c).getBoolean("feedback", true)
    fun setFeedback(c: Context, v: Boolean) = sp(c).edit().putBoolean("feedback", v).apply()

    fun intervalSec(c: Context): Int = sp(c).getInt("intervalSec", 5).coerceIn(1, 120)
    fun setIntervalSec(c: Context, v: Int) =
        sp(c).edit().putInt("intervalSec", v.coerceIn(1, 120)).apply()

    fun pageCount(c: Context): Int = sp(c).getInt("pageCount", 0).coerceIn(0, 999)
    fun setPageCount(c: Context, v: Int) =
        sp(c).edit().putInt("pageCount", v.coerceIn(0, 999)).apply()

    fun loopStyle(c: Context): Int = sp(c).getInt("loopStyle", LOOP_TOP).coerceIn(0, 2)
    fun setLoopStyle(c: Context, v: Int) = sp(c).edit().putInt("loopStyle", v).apply()
}
