package com.pagepilot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max

/**
 * 无障碍服务：
 *  1. 用 TYPE_ACCESSIBILITY_OVERLAY 在所有应用上层显示悬浮翻页条（不需要单独的悬浮窗权限）；
 *  2. 用 dispatchGesture 模拟滑动 / 点击来翻页，或用无障碍滚动指令翻页；
 *  3. 提供定时自动循环翻页。
 */
class PagerService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: PagerService? = null
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var body: LinearLayout? = null
    private var autoBtn: TextView? = null
    private var collapsed = false

    private var auto = false
    private var logic: AutoPagerLogic? = null

    // ---------------------------------------------------------------- 生命周期

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        panel?.post { clampPanel() }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        hidePanel()
        instance = null
    }

    // ---------------------------------------------------------------- 悬浮条

    fun isPanelShown(): Boolean = panel != null

    fun showPanel() {
        if (panel != null) return
        val (sw, sh) = screenSize()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(4), dp(4), dp(4), dp(4))
        val bg = GradientDrawable()
        bg.setColor(Color.argb(205, 28, 28, 30))
        bg.cornerRadius = dp(16).toFloat()
        root.background = bg

        val handle = makeButton("≡") {}
        val prev = makeButton("▲") { manualStep(Step.PREV) }
        val next = makeButton("▼") { manualStep(Step.NEXT) }
        val autoButton = makeButton("自动") { toggleAuto() }
        autoButton.textSize = 14f

        val bodyLayout = LinearLayout(this)
        bodyLayout.orientation = LinearLayout.VERTICAL
        bodyLayout.addView(prev)
        bodyLayout.addView(next)
        bodyLayout.addView(autoButton)

        root.addView(handle)
        root.addView(bodyLayout)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = sw.toInt() - dp(64)
        lp.y = sh.toInt() / 3

        attachDrag(handle, lp, root)

        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            return
        }
        panel = root
        panelParams = lp
        body = bodyLayout
        autoBtn = autoButton
        collapsed = false
    }

    fun hidePanel() {
        stopAuto()
        val p = panel ?: return
        try {
            wm.removeView(p)
        } catch (e: Exception) {
            // 视图已经不在窗口里了，忽略
        }
        panel = null
        panelParams = null
        body = null
        autoBtn = null
    }

    private fun makeButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 18f
        t.gravity = Gravity.CENTER
        t.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        t.setOnClickListener { onClick() }
        return t
    }

    /** 按住最上面的“≡”拖动；轻点则折叠 / 展开。 */
    private fun attachDrag(handle: View, lp: WindowManager.LayoutParams, root: View) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        val slop = dp(6).toFloat()

        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        val (sw, sh) = screenSize()
                        lp.x = (startX + dx).toInt().coerceIn(0, max(0, sw.toInt() - root.width))
                        lp.y = (startY + dy).toInt().coerceIn(0, max(0, sh.toInt() - root.height))
                        try {
                            wm.updateViewLayout(root, lp)
                        } catch (ex: Exception) {
                            // 忽略
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleCollapse()
                    true
                }
                else -> false
            }
        }
    }

    private fun toggleCollapse() {
        collapsed = !collapsed
        body?.visibility = if (collapsed) View.GONE else View.VISIBLE
        panel?.post { clampPanel() }
    }

    private fun clampPanel() {
        val p = panel ?: return
        val lp = panelParams ?: return
        val (sw, sh) = screenSize()
        lp.x = lp.x.coerceIn(0, max(0, sw.toInt() - p.width))
        lp.y = lp.y.coerceIn(0, max(0, sh.toInt() - p.height))
        try {
            wm.updateViewLayout(p, lp)
        } catch (e: Exception) {
            // 忽略
        }
    }

    // ---------------------------------------------------------------- 翻页

    private fun manualStep(step: Step) {
        if (auto) {
            stopAuto()
            toast("已暂停自动翻页")
        }
        doStep(step, Prefs.feedback(this))
    }

    /** 当前屏幕的真实大小（旋转后也是对的）。 */
    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Float, Float> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.maximumWindowMetrics.bounds
            Pair(b.width().toFloat(), b.height().toFloat())
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels.toFloat(), dm.heightPixels.toFloat())
        }
    }

    /** 执行一次翻页。feedback = true 时弹出提示，说明这次操作的结果。 */
    private fun doStep(step: Step, feedback: Boolean = false, onDone: () -> Unit = {}) {
        // NEXT 且没有勾选“方向反了” → 向前；勾选后反过来
        val forward = (step == Step.NEXT) != Prefs.invert(this)

        val mode = Prefs.gestureMode(this)
        if (mode == Prefs.MODE_SCROLL) {
            doScroll(forward, feedback, onDone)
            return
        }

        val (w, h) = screenSize()

        // 手势尽量避开悬浮条所在的位置，免得点到悬浮条自己
        val lp = panelParams
        val pv = panel
        val avoidX = if (lp != null && pv != null) lp.x + pv.width / 2f else -1f
        val avoidY = if (lp != null && pv != null) lp.y + pv.height / 2f else -1f

        val style = Prefs.swipeStyle(this)
        val swipeMs: Long = when (style) {
            Prefs.STYLE_FAST -> 100L
            Prefs.STYLE_SLOW -> 450L
            else -> 220L
        }
        val span: Float = when (style) {
            Prefs.STYLE_FAST -> 0.55f
            Prefs.STYLE_SLOW -> 0.5f
            else -> 0.4f
        }

        val path = Path()
        val duration: Long
        when (mode) {
            Prefs.MODE_HORIZONTAL -> {
                val y = pickLane(h * 0.35f, h * 0.65f, avoidY)
                val half = (span + 0.2f) / 2f
                val from = if (forward) w * (0.5f + half) else w * (0.5f - half)
                val to = if (forward) w * (0.5f - half) else w * (0.5f + half)
                path.moveTo(from, y)
                path.lineTo(to, y)
                duration = swipeMs
            }
            Prefs.MODE_TAP -> {
                val y = pickLane(h * 0.25f, h * 0.75f, avoidY)
                val x = if (forward) w * 0.85f else w * 0.15f
                path.moveTo(x, y)
                duration = 60L
            }
            else -> {
                val x = pickLane(w * 0.3f, w * 0.7f, avoidX)
                val half = span / 2f
                val from = if (forward) h * (0.5f + half) else h * (0.5f - half)
                val to = if (forward) h * (0.5f - half) else h * (0.5f + half)
                path.moveTo(x, from)
                path.lineTo(x, to)
                duration = swipeMs
            }
        }

        val stroke = GestureDescription.StrokeDescription(path, 0L, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val accepted = dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (feedback) toast("手势已执行")
                    onDone()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (feedback) toast("手势被取消（可能被系统或应用拦截）")
                    onDone()
                }
            },
            null
        )
        if (!accepted) {
            if (feedback) toast("系统没有接受这个手势")
            onDone()
        }
    }

    private fun pickLane(a: Float, b: Float, avoid: Float): Float =
        if (abs(a - avoid) >= abs(b - avoid)) a else b

    /** 备用方式：找到当前界面里最大的可滚动区域，发送“向前 / 向后滚动”指令。 */
    private fun doScroll(forward: Boolean, feedback: Boolean, onDone: () -> Unit) {
        val root = rootInActiveWindow
        val target = if (root == null) null else pickScrollable(root)
        if (target == null) {
            if (feedback) toast("没找到可滚动的区域")
            onDone()
            return
        }
        val action = if (forward) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        val ok = target.performAction(action)
        if (feedback) toast(if (ok) "已发送滚动指令" else "滚动指令没有生效")
        onDone()
    }

    private fun pickScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val list = ArrayList<AccessibilityNodeInfo>()
        collectScrollable(root, list, 0)
        var best: AccessibilityNodeInfo? = null
        var bestArea = -1L
        val r = Rect()
        for (n in list) {
            n.getBoundsInScreen(r)
            val area = r.width().toLong() * r.height().toLong()
            if (area > bestArea) {
                bestArea = area
                best = n
            }
        }
        return best
    }

    private fun collectScrollable(
        node: AccessibilityNodeInfo?,
        out: MutableList<AccessibilityNodeInfo>,
        depth: Int
    ) {
        if (node == null || depth > 40) return
        if (node.isScrollable && node.isVisibleToUser) out.add(node)
        for (i in 0 until node.childCount) {
            collectScrollable(node.getChild(i), out, depth + 1)
        }
    }

    // ---------------------------------------------------------------- 自动循环

    private val tick = object : Runnable {
        override fun run() {
            if (!auto) return
            if (Prefs.loopStyle(this@PagerService) == Prefs.LOOP_TOP) {
                tickTop()
                return
            }
            val steps = logic?.nextTick() ?: return
            runSteps(steps, 0) { scheduleNext() }
        }
    }

    private fun scheduleNext() {
        if (auto) handler.postDelayed(tick, Prefs.intervalSec(this) * 1000L)
    }

    /** “自动回到最顶部”：能往后翻就翻；翻到底了，就连续往回翻到最顶部，再继续往后翻。 */
    private fun tickTop() {
        if (!auto) return
        if (Prefs.gestureMode(this) == Prefs.MODE_SCROLL) {
            val node = currentScrollable()
            val ok = node?.performAction(scrollAction(Step.NEXT).id) ?: false
            if (ok) scheduleNext() else rewindToTop(0) { scheduleNext() }
            return
        }
        if (isAtEnd()) {
            rewindToTop(0) { scheduleNext() }
        } else {
            doStep(Step.NEXT) { scheduleNext() }
        }
    }

    private fun currentScrollable(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return pickScrollable(root)
    }

    /** 这一步对应的滚动动作：NEXT = 向前（勾选“方向反了”则相反）。 */
    private fun scrollAction(step: Step): AccessibilityNodeInfo.AccessibilityAction {
        val forward = (step == Step.NEXT) != Prefs.invert(this)
        return if (forward) {
            AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD
        }
    }

    /** 当前可滚动区域是否已经没法继续往后翻了。找不到可滚动区域时返回 false。 */
    private fun isAtEnd(): Boolean {
        val node = currentScrollable() ?: return false
        return !node.actionList.contains(scrollAction(Step.NEXT))
    }

    /** 连续往回翻，直到翻不动（到了最顶部）为止，最多 150 次。 */
    private fun rewindToTop(n: Int, done: () -> Unit) {
        if (!auto) return
        if (n >= 150) {
            done()
            return
        }
        val node = currentScrollable()
        if (Prefs.gestureMode(this) == Prefs.MODE_SCROLL) {
            val ok = node?.performAction(scrollAction(Step.PREV).id) ?: false
            if (ok) {
                handler.postDelayed({ rewindToTop(n + 1, done) }, 120L)
            } else {
                done()
            }
            return
        }
        if (node != null && !node.actionList.contains(scrollAction(Step.PREV))) {
            done() // 已经在最顶部
            return
        }
        doStep(Step.PREV) {
            handler.postDelayed({ rewindToTop(n + 1, done) }, 300L)
        }
    }

    /** 依次执行 steps（退回第一页时会连续执行多次），全部完成后调用 done。 */
    private fun runSteps(steps: List<Step>, i: Int, done: () -> Unit) {
        if (!auto) return
        if (i >= steps.size) {
            done()
            return
        }
        doStep(steps[i]) {
            handler.postDelayed({ runSteps(steps, i + 1, done) }, 350L)
        }
    }

    private fun toggleAuto() {
        if (auto) {
            stopAuto()
            toast("自动翻页已停止")
        } else {
            startAuto()
        }
    }

    private fun startAuto() {
        logic = AutoPagerLogic(
            Prefs.pageCount(this),
            Prefs.loopStyle(this) == Prefs.LOOP_RESTART
        )
        auto = true
        updateAutoButton()
        if (Prefs.loopStyle(this) == Prefs.LOOP_TOP) {
            toast("自动翻页开始：到底后会自动回到最顶部")
        } else {
            toast("自动翻页开始（请确认 PPT 在第 1 页）")
        }
        handler.postDelayed(tick, Prefs.intervalSec(this) * 1000L)
    }

    private fun stopAuto() {
        auto = false
        handler.removeCallbacks(tick)
        updateAutoButton()
    }

    private fun updateAutoButton() {
        autoBtn?.text = if (auto) "停止" else "自动"
        autoBtn?.setTextColor(if (auto) Color.parseColor("#FF8A65") else Color.WHITE)
    }

    // ---------------------------------------------------------------- 小工具

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
