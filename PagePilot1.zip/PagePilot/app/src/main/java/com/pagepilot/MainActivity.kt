package com.pagepilot

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** 设置页：开启服务、显示/隐藏悬浮条、选择翻页方式和自动循环参数。 */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var errSection: LinearLayout
    private lateinit var errText: TextView
    private lateinit var intervalEt: EditText
    private lateinit var countEt: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(24))
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        val title = text("翻页助手 1.2")
        title.textSize = 26f
        title.setTypeface(title.typeface, Typeface.BOLD)
        root.addView(title)
        root.addView(text("在其他应用（PPT、WPS、学习通、PDF、网页……）上层显示一个悬浮翻页条：点 ▲ 上一页、▼ 下一页，也可以定时自动循环翻页。"))

        status = text("")
        root.addView(status)

        // 出错记录：平时看不到；万一出过错，这里会显示原因，截图发给开发者即可
        errSection = LinearLayout(this)
        errSection.orientation = LinearLayout.VERTICAL
        errSection.visibility = View.GONE
        val errTitle = text("上次出错的记录（请截图发给我）：")
        errTitle.setTextColor(Color.parseColor("#B71C1C"))
        errTitle.setTypeface(errTitle.typeface, Typeface.BOLD)
        errSection.addView(errTitle)
        errText = text("")
        errText.textSize = 12f
        errText.setTextIsSelectable(true)
        errSection.addView(errText)
        errSection.addView(button("复制出错记录") { copyError() })
        errSection.addView(button("清除出错记录") {
            CrashLog.clear(this)
            refreshError()
        })
        root.addView(errSection)

        root.addView(button("① 打开无障碍设置（找到“翻页助手”并开启）") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("② 显示 / 隐藏悬浮条") { togglePanel() })

        root.addView(section("翻页方式"))
        root.addView(text("先试第一种；点了没反应，就依次换后面的（改完回到要翻页的应用，再点悬浮条）。"))
        root.addView(
            radioGroup(
                listOf(
                    "上下滑动（上滑 = 下一页）",
                    "左右滑动（左滑 = 下一页）",
                    "点击屏幕右侧 / 左侧",
                    "系统滚动指令（备用：滑动没反应时试这个）"
                ),
                Prefs.gestureMode(this)
            ) { Prefs.setGestureMode(this, it) }
        )

        root.addView(text("滑动力度（只对前两种滑动方式有效）："))
        root.addView(
            radioGroup(
                listOf("标准", "快速甩动", "慢速拖动"),
                Prefs.swipeStyle(this)
            ) { Prefs.setSwipeStyle(this, it) }
        )

        val inv = CheckBox(this)
        inv.text = "方向反了？勾选后“上一页 / 下一页”互换"
        inv.isChecked = Prefs.invert(this)
        inv.setOnCheckedChangeListener { _, checked -> Prefs.setInvert(this, checked) }
        root.addView(inv)

        val fb = CheckBox(this)
        fb.text = "点悬浮条后弹出提示，说明这次操作的结果"
        fb.isChecked = Prefs.feedback(this)
        fb.setOnCheckedChangeListener { _, checked -> Prefs.setFeedback(this, checked) }
        root.addView(fb)

        root.addView(section("自动循环翻页"))
        root.addView(text("每隔几秒翻一页（秒）："))
        intervalEt = numberField(Prefs.intervalSec(this))
        root.addView(intervalEt)
        root.addView(text("翻到最后一页之后："))
        root.addView(
            radioGroup(
                listOf(
                    "自动回到最顶部，再继续往后翻（推荐，不用填页数）",
                    "往返：倒着翻回第一页，再正着翻（要填总页数）",
                    "快速退回第一页，再继续往后翻（要填总页数）"
                ),
                loopStyleToIndex(Prefs.loopStyle(this))
            ) { Prefs.setLoopStyle(this, indexToLoopStyle(it)) }
        )
        root.addView(text("PPT 总页数（后两种方式才需要；填 0 表示不知道）："))
        countEt = numberField(Prefs.pageCount(this))
        root.addView(countEt)

        root.addView(section("使用提示"))
        root.addView(
            text(
                "• 点悬浮条上的“自动”开始自动翻页，点“停止”结束；手动点 ▲ ▼ 会暂停自动翻页。\n" +
                    "• 选“往返”或“快速退回第一页”时，开始前请先把 PPT 翻到第 1 页。\n" +
                    "• 按住悬浮条最上面的“≡”可以拖动位置；轻点它可以折叠 / 展开。\n" +
                    "• 无障碍服务只用来模拟翻页操作和查找可滚动区域，不会保存或上传屏幕内容；本应用没有联网权限。"
            )
        )
    }

    override fun onResume() {
        super.onResume()
        status.text = if (PagerService.instance != null) {
            "状态：无障碍服务已开启 ✓"
        } else {
            "状态：还没开启无障碍服务（先点下面第①个按钮）"
        }
        refreshError()
    }

    private fun refreshError() {
        val log = CrashLog.last(this)
        if (log == null) {
            errSection.visibility = View.GONE
        } else {
            errText.text = log
            errSection.visibility = View.VISIBLE
        }
    }

    private fun copyError() {
        val log = CrashLog.last(this) ?: return
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("pagepilot-error", log))
            Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show()
        } catch (e: Throwable) {
            Toast.makeText(this, "复制失败，请直接截图", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPause() {
        super.onPause()
        Prefs.setIntervalSec(this, intervalEt.text.toString().toIntOrNull() ?: 5)
        Prefs.setPageCount(this, countEt.text.toString().toIntOrNull() ?: 0)
    }

    private fun togglePanel() {
        val svc = PagerService.instance
        if (svc == null) {
            Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show()
        } else if (svc.isPanelShown()) {
            svc.hidePanel()
        } else {
            svc.showPanel()
        }
    }

    // 界面上“回到最顶部”排第一，但存储值里它是 LOOP_TOP = 2
    private fun loopStyleToIndex(style: Int): Int = when (style) {
        Prefs.LOOP_TOP -> 0
        Prefs.LOOP_PINGPONG -> 1
        else -> 2
    }

    private fun indexToLoopStyle(index: Int): Int = when (index) {
        0 -> Prefs.LOOP_TOP
        1 -> Prefs.LOOP_PINGPONG
        else -> Prefs.LOOP_RESTART
    }

    // ---------------------------------------------------------------- 小工具

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun text(s: String): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = 15f
        t.setPadding(0, dp(6), 0, dp(6))
        return t
    }

    private fun section(s: String): TextView {
        val t = text(s)
        t.textSize = 18f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.setPadding(0, dp(20), 0, dp(6))
        return t
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { onClick() }
        return b
    }

    private fun numberField(v: Int): EditText {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(v.toString())
        return e
    }

    private fun radioGroup(labels: List<String>, selected: Int, onPick: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = LinearLayout.VERTICAL
        for (l in labels) {
            val rb = RadioButton(this)
            rb.text = l
            rb.id = View.generateViewId()
            g.addView(rb)
        }
        (g.getChildAt(selected) as RadioButton).isChecked = true
        g.setOnCheckedChangeListener { group, checkedId ->
            onPick(group.indexOfChild(group.findViewById<View>(checkedId)))
        }
        return g
    }
}
