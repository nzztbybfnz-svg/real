package com.pagepilot

enum class Step { NEXT, PREV }

/**
 * 自动翻页的纯逻辑（不依赖 Android，方便单独测试）。
 *
 * 每调用一次 [nextTick]（对应一次定时器触发），返回这一次要执行的翻页动作列表。
 * 约定开始时 PPT 停在第 1 页。
 *
 * - pageCount <= 1：不知道总页数，一直向后翻，由放映软件自己决定要不要循环。
 * - restart = false（往返）：翻到最后一页后，倒着一页一页翻回第 1 页，再正着翻，如此循环。
 * - restart = true：翻到最后一页后，下一次触发时一口气退回第 1 页，然后继续往后翻。
 */
class AutoPagerLogic(private val pageCount: Int, private val restart: Boolean) {
    private var index = 0      // 当前所在页，从 0 开始
    private var back = false   // 往返模式下，是否正在往回翻

    fun nextTick(): List<Step> {
        if (pageCount <= 1) return listOf(Step.NEXT)
        val last = pageCount - 1

        if (restart) {
            return if (index >= last) {
                index = 0
                List(last) { Step.PREV }
            } else {
                index++
                listOf(Step.NEXT)
            }
        }

        if (!back && index >= last) back = true
        if (back && index <= 0) back = false
        return if (back) {
            index--
            listOf(Step.PREV)
        } else {
            index++
            listOf(Step.NEXT)
        }
    }
}
