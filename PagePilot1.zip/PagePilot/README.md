# 翻页助手（PagePilot）1.1

安卓悬浮翻页条：叠在任何应用上层，点 ▲ 上一页、▼ 下一页，并可定时自动循环翻页（适合放映 PPT、WPS、学习通、PDF、网页）。

## 工作原理

- 一个**无障碍服务**；悬浮条用无障碍悬浮窗（`TYPE_ACCESSIBILITY_OVERLAY`）显示，不需要额外的“显示在其他应用上层”权限。
- 翻页有四种方式，可在设置页切换：
  1. 上下滑动、2. 左右滑动、3. 点击屏幕右侧 / 左侧：用 `dispatchGesture` 模拟手指操作；
  4. 系统滚动指令：找到当前界面里最大的可滚动区域，发送“向前 / 向后滚动”指令（备用，某些应用不理会模拟手势时可以试试）。
- 无障碍服务只用来模拟翻页和查找可滚动区域，不保存、不上传屏幕内容；应用没有申请联网权限。

## 得到 APK（用 GitHub 在线打包，不需要装开发环境）

仓库里放两样东西：根目录的 `PagePilot.zip`（就是本项目打成的压缩包），和 `.github/workflows/main.yml`（打包配置，内容见下方）。每次更新 `PagePilot.zip`（文件名必须一样），GitHub 会自动重新打包，并把 `app-debug.apk` 发布到仓库的 **Releases** 页面，手机浏览器打开就能下载，不需要登录。

打包配置 `main.yml`：

```yaml
name: Build APK

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - uses: actions/checkout@v4

      - name: Unzip project
        run: unzip -q PagePilot.zip

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - name: Accept Android SDK licenses
        run: yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true

      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: "8.9"

      - name: Build debug APK
        working-directory: PagePilot
        run: gradle assembleDebug --no-daemon

      - uses: actions/upload-artifact@v4
        with:
          name: PagePilot-debug-apk
          path: PagePilot/app/build/outputs/apk/debug/app-debug.apk

      - name: Publish APK to Releases
        uses: softprops/action-gh-release@v2
        with:
          tag_name: v1.0
          name: PagePilot v1.0
          files: PagePilot/app/build/outputs/apk/debug/app-debug.apk
```

也可以用 Android Studio 直接打开本文件夹打包（Build → Build APK(s)）。

## 安装和使用

1. 安装 `app-debug.apk`（允许“安装未知来源应用”）。**更新版本前先卸载旧版**：每次在线打包使用的调试签名不同，直接覆盖安装会失败。
2. 打开“翻页助手”，点 **① 打开无障碍设置**，找到“翻页助手”并开启。
   - Android 13 及以上，如果开关是灰色的：设置 → 应用 → 翻页助手 → 右上角 ⋮ → **允许受限制的设置**，再回去开启。
3. 开启后屏幕上会出现悬浮条。回到要翻页的应用，点 ▲ ▼。
4. 点了没反应：在“翻页方式”里依次换成“左右滑动”“点击左右侧”“系统滚动指令”；还可以换“滑动力度”。保持勾选“点悬浮条后弹出提示”，会显示手势是否被执行、被取消或被系统拒绝。

## 自动循环

- 点悬浮条上的“自动”开始，“停止”结束；每隔几秒翻一页，间隔在设置页里改。
- 到最后一页之后有三种做法：
  - **自动回到最顶部，再继续往后翻**（默认，不用填页数）：检测到翻不动了，就连续往回翻到最顶部，再重新往后翻。需要应用的滚动区域能被无障碍服务识别。
  - **往返** / **快速退回第一页**：需要填写 PPT 总页数，并且开始前先翻到第 1 页。

## 已知限制

- 部分手机的省电策略会杀掉后台服务：到电池设置里把“翻页助手”设为“不限制”。
- 个别应用会忽略或拦截模拟操作，这种情况下本工具无法生效。
- 源码没有在真机上测试过，不同手机 / 不同应用的手势位置可能需要微调（见 `PagerService.kt` 里的 `doStep`）。
